/* Jungo Connectivity Confidential. Copyright (c) 2024 Jungo Connectivity Ltd.  https://www.jungo.com */

#ifndef _WD_KP_H_
#define _WD_KP_H_

#ifndef __KERNEL__
    #define __KERNEL__
#endif

#ifndef __KERPLUG__
    #define __KERPLUG__
#endif

#include "windrvr.h"

#ifdef __cplusplus
    extern "C" {
#endif  /* __cplusplus */

/** Called when WD_KernelPlugInClose() is called */
typedef void (__cdecl *KP_FUNC_CLOSE)(PVOID pDrvContext);
/** Called when WD_KernelPlugInCall() is called */
typedef void (__cdecl *KP_FUNC_CALL)(PVOID pDrvContext,
    WD_KERNEL_PLUGIN_CALL *kpCall);
/** Called when WD_IntEnable() is called, with a kernel plugin handler specified
  the pIntContext will be passed to the rest of the functions handling
  interrupts. Returns TRUE if enable is successful */
typedef BOOL (__cdecl *KP_FUNC_INT_ENABLE)(PVOID pDrvContext,
    WD_KERNEL_PLUGIN_CALL *kpCall, PVOID *ppIntContext);
/** Called when WD_IntDisable() is called */
typedef void (__cdecl *KP_FUNC_INT_DISABLE)(PVOID pIntContext);
/** Returns TRUE if needs DPC. */
typedef BOOL (__cdecl *KP_FUNC_INT_AT_IRQL)(PVOID pIntContext,
    BOOL *pfIsMyInterrupt);
/** Returns the number of times to notify user-mode (i.e. return from
    WD_IntWait) */
typedef DWORD (__cdecl *KP_FUNC_INT_AT_DPC)(PVOID pIntContext, DWORD dwCount);
/** Returns TRUE if needs DPC. */
typedef BOOL (__cdecl *KP_FUNC_INT_AT_IRQL_MSI)(PVOID pIntContext,
    ULONG dwLastMessage, DWORD dwReserved);
/** Returns the number of times to notify user-mode (i.e. return from
    WD_IntWait) */
typedef DWORD (__cdecl *KP_FUNC_INT_AT_DPC_MSI)(PVOID pIntContext,
    DWORD dwCount, ULONG dwLastMessage, DWORD dwReserved);
/** returns TRUE if user need notification */
typedef BOOL (__cdecl *KP_FUNC_EVENT)(PVOID pDrvContext, WD_EVENT *wd_event);

typedef struct
{
    KP_FUNC_CLOSE funcClose;
    KP_FUNC_CALL funcCall;
    KP_FUNC_INT_ENABLE funcIntEnable;
    KP_FUNC_INT_DISABLE funcIntDisable;
    KP_FUNC_INT_AT_IRQL funcIntAtIrql;
    KP_FUNC_INT_AT_DPC funcIntAtDpc;
    KP_FUNC_INT_AT_IRQL_MSI funcIntAtIrqlMSI;
    KP_FUNC_INT_AT_DPC_MSI funcIntAtDpcMSI;
    KP_FUNC_EVENT funcEvent;
} KP_OPEN_CALL;

/** Called when WD_KernelPlugInOpen() is called. pDrvContext returned will
   be passed to rest of the functions */
typedef BOOL (__cdecl *KP_FUNC_OPEN)(KP_OPEN_CALL *kpOpenCall, HANDLE hWD,
    PVOID pOpenData, PVOID *ppDrvContext);

typedef struct
{
    DWORD dwVerWD; /**< version of the WinDriver Kernel PlugIn library */
    CHAR cDriverName[WD_MAX_KP_NAME_LENGTH]; /**< return the device driver
                                               name */
    KP_FUNC_OPEN funcOpen; /**< returns the KP_Open function */
    KP_FUNC_OPEN funcOpen_32_64; /**< returns the KP_Open function for 32 bit
                                   app with 64 bit KP. */
} KP_INIT;

/** You must define a KP_Init() function to link to the device driver */
BOOL __cdecl KP_Init(KP_INIT *kpInit);

#ifdef __cplusplus
    }
#endif  /* __cplusplus */

#endif /* _WD_KP_H_ */

