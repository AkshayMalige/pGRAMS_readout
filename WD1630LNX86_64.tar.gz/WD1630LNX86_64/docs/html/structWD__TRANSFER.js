var structWD__TRANSFER =
[
    [ "Byte", "structWD__TRANSFER_a333d1bf07466bd9686f1078856613101.html#a333d1bf07466bd9686f1078856613101", null ],
    [ "cmdTrans", "structWD__TRANSFER_a31617c76585d5a5ac91fc21fee963b89.html#a31617c76585d5a5ac91fc21fee963b89", null ],
    [ "Data", "structWD__TRANSFER_a98e4642f5755fb8489bb9a051fa1e84b.html#a98e4642f5755fb8489bb9a051fa1e84b", null ],
    [ "dwBytes", "structWD__TRANSFER_a0b9d7cd2c326fca15f8247efab034ed9.html#a0b9d7cd2c326fca15f8247efab034ed9", null ],
    [ "dwOptions", "structWD__TRANSFER_a26202486a045b222d430e3875dcc5e7b.html#a26202486a045b222d430e3875dcc5e7b", null ],
    [ "Dword", "structWD__TRANSFER_a39c469a758668fb12f9efaf59047ef38.html#a39c469a758668fb12f9efaf59047ef38", null ],
    [ "fAutoinc", "structWD__TRANSFER_aab64783823f518c6d31f0de956416833.html#aab64783823f518c6d31f0de956416833", null ],
    [ "pBuffer", "structWD__TRANSFER_adb35daf22c1db6fc42cf66fed26cccab.html#adb35daf22c1db6fc42cf66fed26cccab", null ],
    [ "pPort", "structWD__TRANSFER_aa109711c8c84ebfa06bde073c6cd7e17.html#aa109711c8c84ebfa06bde073c6cd7e17", null ],
    [ "Qword", "structWD__TRANSFER_a021a2b9094f94333d2b6330468b3f175.html#a021a2b9094f94333d2b6330468b3f175", null ],
    [ "Word", "structWD__TRANSFER_a3c10a82c788befbe24146be63feda1b9.html#a3c10a82c788befbe24146be63feda1b9", null ]
];