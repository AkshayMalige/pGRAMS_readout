var structWD__PCI__CARD__INFO =
[
    [ "Card", "structWD__PCI__CARD__INFO_a5bf5a89cb1bff1f545d9437964f98902.html#a5bf5a89cb1bff1f545d9437964f98902", null ],
    [ "pciSlot", "structWD__PCI__CARD__INFO_ad0fd95adc43cef8c3514296e291d80fa.html#ad0fd95adc43cef8c3514296e291d80fa", null ]
];