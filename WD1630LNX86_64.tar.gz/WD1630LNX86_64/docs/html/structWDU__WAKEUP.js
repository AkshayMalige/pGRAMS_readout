var structWDU__WAKEUP =
[
    [ "dwOptions", "structWDU__WAKEUP_a17e2229bf9c60ad6c2fd6aca9d5ed345.html#a17e2229bf9c60ad6c2fd6aca9d5ed345", null ],
    [ "dwUniqueID", "structWDU__WAKEUP_a4d26e7a999475c96932382ddf6b7d6d5.html#a4d26e7a999475c96932382ddf6b7d6d5", null ]
];