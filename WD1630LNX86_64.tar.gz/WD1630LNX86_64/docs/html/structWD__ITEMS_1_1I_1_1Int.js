var structWD__ITEMS_1_1I_1_1Int =
[
    [ "dwInterrupt", "structWD__ITEMS_1_1I_1_1Int_a79f8658201f02c64b44e818d1c5ab733.html#a79f8658201f02c64b44e818d1c5ab733", null ],
    [ "dwOptions", "structWD__ITEMS_1_1I_1_1Int_a667159c73fb6e89010548c28f92a2dd6.html#a667159c73fb6e89010548c28f92a2dd6", null ],
    [ "dwReserved1", "structWD__ITEMS_1_1I_1_1Int_aa0f87c955b445ce62b49aff2b81163a4.html#aa0f87c955b445ce62b49aff2b81163a4", null ],
    [ "hInterrupt", "structWD__ITEMS_1_1I_1_1Int_a4d89df1363c2d3186ff69ada2f6721f8.html#a4d89df1363c2d3186ff69ada2f6721f8", null ],
    [ "pReserved2", "structWD__ITEMS_1_1I_1_1Int_aff56ab12d333f7cf1feab8b158e27b4e.html#aff56ab12d333f7cf1feab8b158e27b4e", null ]
];