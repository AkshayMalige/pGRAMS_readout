var structWDU__HALT__TRANSFER =
[
    [ "dwOptions", "structWDU__HALT__TRANSFER_a1282ff90a50be5c80e9354eb76704e79.html#a1282ff90a50be5c80e9354eb76704e79", null ],
    [ "dwPipeNum", "structWDU__HALT__TRANSFER_a0b9974eead7b103bd51ce83f30f69b41.html#a0b9974eead7b103bd51ce83f30f69b41", null ],
    [ "dwUniqueID", "structWDU__HALT__TRANSFER_a3360a5e7fc0f18f8d8e4af7fe6cde175.html#a3360a5e7fc0f18f8d8e4af7fe6cde175", null ]
];