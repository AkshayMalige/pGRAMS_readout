var structWD__PCI__ID =
[
    [ "dwDeviceId", "structWD__PCI__ID_a87069485afdc04998be58aff310c633a.html#a87069485afdc04998be58aff310c633a", null ],
    [ "dwVendorId", "structWD__PCI__ID_a58a7ae4b249bb497497e237dfd5781f6.html#a58a7ae4b249bb497497e237dfd5781f6", null ]
];