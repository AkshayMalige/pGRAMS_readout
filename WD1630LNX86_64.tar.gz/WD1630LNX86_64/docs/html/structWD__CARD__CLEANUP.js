var structWD__CARD__CLEANUP =
[
    [ "Cmd", "structWD__CARD__CLEANUP_a60e0c498da36e12d99c12848069bb0fc.html#a60e0c498da36e12d99c12848069bb0fc", null ],
    [ "dwCmds", "structWD__CARD__CLEANUP_a8d0a4159f39485046c1524147db1331e.html#a8d0a4159f39485046c1524147db1331e", null ],
    [ "dwOptions", "structWD__CARD__CLEANUP_a20e7ba36cdd328fee89af7c2ae233e4d.html#a20e7ba36cdd328fee89af7c2ae233e4d", null ],
    [ "hCard", "structWD__CARD__CLEANUP_a56e43bca07edbb3b5d71ee02778ace3b.html#a56e43bca07edbb3b5d71ee02778ace3b", null ]
];