var wd__kp_8h =
[
    [ "KP_OPEN_CALL", "structKP__OPEN__CALL.html", "structKP__OPEN__CALL" ],
    [ "KP_INIT", "structKP__INIT.html", "structKP__INIT" ],
    [ "__KERNEL__", "wd__kp_8h_aff0383591d2590e91f755a89beafdaf4.html#aff0383591d2590e91f755a89beafdaf4", null ],
    [ "__KERPLUG__", "wd__kp_8h_aeed169430f525d4f08619c0ce77ae211.html#aeed169430f525d4f08619c0ce77ae211", null ],
    [ "KP_FUNC_CALL", "wd__kp_8h_a27fd15b352b337761f39a494170bfa89.html#a27fd15b352b337761f39a494170bfa89", null ],
    [ "KP_FUNC_CLOSE", "wd__kp_8h_ab7d9eed8635eb1d90dadbf6f84a98a4a.html#ab7d9eed8635eb1d90dadbf6f84a98a4a", null ],
    [ "KP_FUNC_EVENT", "wd__kp_8h_a29bcc6b285d36c114584c66aeb46e18e.html#a29bcc6b285d36c114584c66aeb46e18e", null ],
    [ "KP_FUNC_INT_AT_DPC", "wd__kp_8h_ac68e46d1ef7667daec2d3a9ee264991a.html#ac68e46d1ef7667daec2d3a9ee264991a", null ],
    [ "KP_FUNC_INT_AT_DPC_MSI", "wd__kp_8h_ae95940bb2a1d8fa53702838d2027e589.html#ae95940bb2a1d8fa53702838d2027e589", null ],
    [ "KP_FUNC_INT_AT_IRQL", "wd__kp_8h_af20f18d772e4819ab916d1f8366aa062.html#af20f18d772e4819ab916d1f8366aa062", null ],
    [ "KP_FUNC_INT_AT_IRQL_MSI", "wd__kp_8h_a74dd11c42873c9d902e3b2a27a52e6ec.html#a74dd11c42873c9d902e3b2a27a52e6ec", null ],
    [ "KP_FUNC_INT_DISABLE", "wd__kp_8h_a5a92a5c11a0bd3d95eefbcdf4085a7c7.html#a5a92a5c11a0bd3d95eefbcdf4085a7c7", null ],
    [ "KP_FUNC_INT_ENABLE", "wd__kp_8h_aa3af2464e79c78646226561e84e38b81.html#aa3af2464e79c78646226561e84e38b81", null ],
    [ "KP_FUNC_OPEN", "wd__kp_8h_ae00f217ac8288e00b35ae345d366f2ec.html#ae00f217ac8288e00b35ae345d366f2ec", null ],
    [ "KP_Init", "wd__kp_8h_ad2d90fcb178eba74eb09dd3da8355fe5.html#ad2d90fcb178eba74eb09dd3da8355fe5", null ]
];