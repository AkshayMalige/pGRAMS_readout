var structKP__OPEN__CALL =
[
    [ "funcCall", "structKP__OPEN__CALL_aa505a9f7a9515638df55a1cf9a635fbf.html#aa505a9f7a9515638df55a1cf9a635fbf", null ],
    [ "funcClose", "structKP__OPEN__CALL_a2df5615557017c3539d52bb5691e6eea.html#a2df5615557017c3539d52bb5691e6eea", null ],
    [ "funcEvent", "structKP__OPEN__CALL_a0d119692c6c190a2879bd49f0acd1045.html#a0d119692c6c190a2879bd49f0acd1045", null ],
    [ "funcIntAtDpc", "structKP__OPEN__CALL_a8f614d13a7551b0da2650b8ada406e28.html#a8f614d13a7551b0da2650b8ada406e28", null ],
    [ "funcIntAtDpcMSI", "structKP__OPEN__CALL_a49e9bc49554ee2b21ae80333f61bd645.html#a49e9bc49554ee2b21ae80333f61bd645", null ],
    [ "funcIntAtIrql", "structKP__OPEN__CALL_a337d0e457ba249815c0da824293f3519.html#a337d0e457ba249815c0da824293f3519", null ],
    [ "funcIntAtIrqlMSI", "structKP__OPEN__CALL_a88b15e530ffb6ee3ec597dff026971e7.html#a88b15e530ffb6ee3ec597dff026971e7", null ],
    [ "funcIntDisable", "structKP__OPEN__CALL_ae4c5bd8c1df0fa1c5cf874ad15313853.html#ae4c5bd8c1df0fa1c5cf874ad15313853", null ],
    [ "funcIntEnable", "structKP__OPEN__CALL_a60601602d5d5e219505d9c434d41422d.html#a60601602d5d5e219505d9c434d41422d", null ]
];