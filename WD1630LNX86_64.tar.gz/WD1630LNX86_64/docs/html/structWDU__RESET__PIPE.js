var structWDU__RESET__PIPE =
[
    [ "dwOptions", "structWDU__RESET__PIPE_a976cfd88e1e34b9a808346921bc38f7f.html#a976cfd88e1e34b9a808346921bc38f7f", null ],
    [ "dwPipeNum", "structWDU__RESET__PIPE_a597d03e21e3c7d96f87e9c80f4f5cc88.html#a597d03e21e3c7d96f87e9c80f4f5cc88", null ],
    [ "dwUniqueID", "structWDU__RESET__PIPE_ac5b91465b4400b4255ba6a8c24e85ce2.html#ac5b91465b4400b4255ba6a8c24e85ce2", null ]
];