var structWDU__SET__INTERFACE =
[
    [ "dwAlternateSetting", "structWDU__SET__INTERFACE_af3f425d49805d381d1ccc453e7254467.html#af3f425d49805d381d1ccc453e7254467", null ],
    [ "dwInterfaceNum", "structWDU__SET__INTERFACE_af2474672c35c5b5946396e4c9bbebbbd.html#af2474672c35c5b5946396e4c9bbebbbd", null ],
    [ "dwOptions", "structWDU__SET__INTERFACE_a41e9cff4296854049a2d636236da46aa.html#a41e9cff4296854049a2d636236da46aa", null ],
    [ "dwUniqueID", "structWDU__SET__INTERFACE_ac90e7e1301006bdae63aeb7db6436a05.html#ac90e7e1301006bdae63aeb7db6436a05", null ]
];