var wd__ver_8h =
[
    [ "COPYRIGHTS_FULL_STR", "wd__ver_8h_a764b79a935693fb3617fa657dad5aff6.html#a764b79a935693fb3617fa657dad5aff6", null ],
    [ "COPYRIGHTS_YEAR_STR", "wd__ver_8h_a2b7c26069168d9032f440214b5d395db.html#a2b7c26069168d9032f440214b5d395db", null ],
    [ "WD_MAJOR_VER", "wd__ver_8h_a805f0061920a6a9bea60904e2d7698f4.html#a805f0061920a6a9bea60904e2d7698f4", null ],
    [ "WD_MAJOR_VER_STR", "wd__ver_8h_ad423a29b635a986e4cd7166f74035e47.html#ad423a29b635a986e4cd7166f74035e47", null ],
    [ "WD_MINOR_VER", "wd__ver_8h_abc762ef2762d92d7660c87df1246952c.html#abc762ef2762d92d7660c87df1246952c", null ],
    [ "WD_MINOR_VER_STR", "wd__ver_8h_ae81d591c2caf11bef195a4a296927d1c.html#ae81d591c2caf11bef195a4a296927d1c", null ],
    [ "WD_SUB_MINOR_VER", "wd__ver_8h_a8806bf8bf7b4d2fc2f83901d9aa67a2e.html#a8806bf8bf7b4d2fc2f83901d9aa67a2e", null ],
    [ "WD_SUB_MINOR_VER_STR", "wd__ver_8h_a357cb531159933c7496a9a0e5dbb59f4.html#a357cb531159933c7496a9a0e5dbb59f4", null ],
    [ "WD_VER", "wd__ver_8h_ae288a3af41d2074d9c6cc2dc6e320e56.html#ae288a3af41d2074d9c6cc2dc6e320e56", null ],
    [ "WD_VER_BETA_STR", "wd__ver_8h_a7174eb476291bd7cb8292332367fee27.html#a7174eb476291bd7cb8292332367fee27", null ],
    [ "WD_VER_ITOA", "wd__ver_8h_a0ce769ca2f6b3052b35d253cf82bd1b5.html#a0ce769ca2f6b3052b35d253cf82bd1b5", null ],
    [ "WD_VERSION_MAC_STR", "wd__ver_8h_a44f546b7a60beb4855db235ba48bd313.html#a44f546b7a60beb4855db235ba48bd313", null ],
    [ "WD_VERSION_STR", "wd__ver_8h_a9dcb09ef13546b373734d2cb30654cf1.html#a9dcb09ef13546b373734d2cb30654cf1", null ]
];