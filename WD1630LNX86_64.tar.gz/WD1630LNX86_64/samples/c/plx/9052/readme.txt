WinDriver PLX 9050 library is fully compatible with PLX 9052.

Therefore, use the files in plx/9050 directory for the PLX 9052 chip.
